import React from 'react';
import { Tabs, Tab } from 'react-bootstrap';
export default function HistoryOrder() {
  return (
    <div className="market-history market-order mt15">
      <Tabs defaultActiveKey="open-orders">
        <Tab eventKey="open-orders" title="Open Orders">
          <ul className="d-flex justify-content-between market-order-item">
            <li>Time</li>
            <li>All pairs</li>
            <li>All Types</li>
            <li>Buy/Sell</li>
            <li>Price</li>
            <li>Amount</li>
            <li>Executed</li>
            <li>Unexecuted</li>
          </ul>
          <span className="no-data">
            <i className="icon ion-md-document"></i>
            No data
          </span>
        </Tab>
        <Tab eventKey="closed-orders" title="Closed Orders">
          <ul className="d-flex justify-content-between market-order-item">
            <li>Time</li>
            <li>All pairs</li>
            <li>All Types</li>
            <li>Buy/Sell</li>
            <li>Price</li>
            <li>Amount</li>
            <li>Executed</li>
            <li>Unexecuted</li>
          </ul>
          <span className="no-data">
            <i className="icon ion-md-document"></i>
            No data
          </span>
        </Tab>
        <Tab eventKey="order-history" title="Order history">
          <ul className="d-flex justify-content-between market-order-item">
            <li>Time</li>
            <li>All pairs</li>
            <li>All Types</li>
            <li>Buy/Sell</li>
            <li>Price</li>
            <li>Amount</li>
            <li>Executed</li>
            <li>Unexecuted</li>
          </ul>
          <span className="no-data">
            <i className="icon ion-md-document"></i>
            No data
          </span>
        </Tab>
        <Tab eventKey="balance" title="Balance">
          <ul className="d-flex justify-content-between market-order-item">
            <li>Time</li>
            <li>All pairs</li>
            <li>All Types</li>
            <li>Buy/Sell</li>
            <li>Price</li>
            <li>Amount</li>
            <li>Executed</li>
            <li>Unexecuted</li>
          </ul>
          <span className="no-data">
            <i className="icon ion-md-document"></i>
            No data
          </span>
        </Tab>
      </Tabs>
    </div>
  );
}
